﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PilhaLista
{
    class Program
    {
        static void Main(string[] args)
        {
            Fila2 f = new Fila2();

            f.Enqueue("ana");
            f.Enqueue("eva");
            f.Enqueue("rui");
            f.Enqueue("bob"); 

            Console.WriteLine("Topo: " + f.Top());
            Console.WriteLine("Tamanho: " + f.Size());
            Console.WriteLine("Vazia?: " + f.IsEmpty());

            f.Imprimir();

            f.Dequeue();

            f.Imprimir();

            Console.Read();
        }


    }
}
