﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PilhaLista
{
    class Fila2
    {
        LinkedList<string> lista = new LinkedList<string>();

        public void Enqueue(String nome)
        {
            lista.AddLast(nome);
        }


        public string Top()
        {

            if (IsEmpty())
            {
                throw new InvalidOperationException("Fila Vazia!");
            }

            return lista.First.Value.ToString();

        }
        public int Size()
        {
            return lista.Count;
        }

        public bool IsEmpty()
        {
            return lista.Count == 0;
        }

        public void Imprimir()
        {
            Console.Write("\n");

            foreach (string nome in lista)
            {
                Console.Write(nome + " | ");
            }

        }

        // public string Dequeue() => lista.RemoveFirst(); //

        public string Dequeue()
        {

            if (IsEmpty())
            {
                throw new InvalidOperationException("Fila Vazia!");
            }

            string nome = lista.First.Value;
            lista.RemoveFirst();
            return nome;

        }
    }
}