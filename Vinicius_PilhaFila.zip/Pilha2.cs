﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PilhaLista
{
    class Pilha2
    {
        LinkedList<string> lista = new LinkedList<string>();

        public void Push(String nome)
        {
            lista.AddLast(nome);
        }

        public void Pop()
        {
            lista.RemoveLast();

        }

        public string Top()
        {
            return lista.Last.Value.ToString();

            /* if (!IsEmpty())
            {
                string nome = Top();
                lista.RemoveLast();
                return nome;
            } */
        }
        public int Size()
        {
            return lista.Count;
        }

         public bool IsEmpty()
        {
            return lista.Count == 0;
        }

       public void Imprimir()
        {
            Console.Write("\n");

            foreach (string nome in lista)
            {
                Console.Write(nome + " | ");
            }
        }
    }
}   
